#!/bin/sh
# Wrapper that points the dynamic loader at the bundled libraries.
HERE="$(cd "$(dirname "$0")" && pwd)"
export LD_LIBRARY_PATH="$HERE/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
exec "$HERE/bin/kicad-cli" "$@"
